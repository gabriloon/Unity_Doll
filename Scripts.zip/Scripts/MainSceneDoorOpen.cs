﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainSceneDoorOpen : MonoBehaviour
{
    public float TheDistance;
    public GameObject ActionDisplay;
    public GameObject Player;
    public GameObject InformationText;
    public GameObject TheDoor;
    public AudioSource CreakSound;
    public AudioSource CloseSound;
    public bool CloseD = true;
    //private float timer = 0f;
    private Animation tempAnim;
    private Transform playerTr;
    private Transform thisTr;
    // Start is called before the first frame update
    void Start()
    {
        tempAnim = TheDoor.GetComponent<Animation>();
        playerTr = Player.GetComponent<Transform>();
        thisTr = this.GetComponent<Transform>();
    }

    void OnMouseOver()
    {//마우스 올라갔을때
        TheDistance = Vector3.Distance(playerTr.position, thisTr.position);
        Debug.Log(TheDistance);
        if (TheDistance <= 4.0f)
        {

            ActionDisplay.SetActive(true);

            if (Input.GetButtonDown("Interaction"))
            {
                //Debug.Log("통과3");
                if (CloseD)
                {
                    StartCoroutine(waitDoor());

                }
                else if (!CloseD)
                {
                   // StartCoroutine(CloseDoor());
                }
            }
        }

    }

    IEnumerator waitDoor()
    {
       
                    tempAnim.Play("MainDoorRAnim");
                    CreakSound.Play();
                    CloseD = false;
            
            yield return new WaitForSeconds(2.0f);

        }
    


IEnumerator CloseDoor() {

    ActionDisplay.SetActive(true);
    // ActionText.SetActive(true);
    tempAnim.Play("CloseTheDoor");//닫히는 애니메이션
    CloseSound.Play();
    CloseD = true;

    yield return new WaitForSeconds(2.0f);
}

    void OnMouseExit()
    {
        ActionDisplay.SetActive(false);
        // ActionText.SetActive(false);
    }
}
