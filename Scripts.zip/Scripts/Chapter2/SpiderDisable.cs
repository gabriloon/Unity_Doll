﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpiderDisable : MonoBehaviour
{
    public GameObject spider;
    private void OnTriggerEnter()
    {
        spider.SetActive(false);
    }
}
