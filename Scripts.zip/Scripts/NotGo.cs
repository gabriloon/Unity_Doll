﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NotGo : MonoBehaviour
{

    public GameObject SystemAlarm;

    private Text tempText;
    // Start is called before the first frame update
    void Start()
    {
        tempText = SystemAlarm.GetComponent<Text>();


    }
    void OnTriggerEnter(Collider other)
    {
        StartCoroutine(systemAlarm());

    }

    IEnumerator systemAlarm() {

        SystemAlarm.SetActive(true);
        tempText.text = "무언가 앞으로 가는 것을 막고 있다.";
        yield return new WaitForSeconds(2.0f);
        tempText.text = "";
      SystemAlarm.SetActive(false);
    }

}
