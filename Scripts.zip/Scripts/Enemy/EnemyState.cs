﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;
using UnityEngine.SceneManagement;

public class EnemyState : MonoBehaviour
{
    public enum State {
        PATROL,
        TRACE,
        ATTACK,
       Clear
    }
    public State state = State.PATROL;
    public GameObject player;
    public GameObject playerFirst;
    public GameObject EnemyCamera;
    public AudioSource ShadowLaugh;
    public GameObject FadeSc;

    public bool isClear=false;//이걸 Awake 내에서 false 로 만들지 고민.
    private Transform playerTr;
    private Transform enemyTr;

    private Animator animator;
    public float attackDist = 5.0f;
    public float traceDist = 10.0f;
    private WaitForSeconds ws;
    private MoveAgent moveAgent;//추가
    private readonly int hashMove = Animator.StringToHash("isMove");
    private readonly int hashSpeed = Animator.StringToHash("Speed");
    private readonly int hashOffset = Animator.StringToHash("Offset");
    private readonly int hashWalkSpeed = Animator.StringToHash("WalkSpeed");
    private readonly int hashKillPlayer = Animator.StringToHash("isKill");
    private float angle;
    private float dist;
    private Animation tempAnim;


    private EnemyFov enemyFov;

    public AudioSource foundS;

    //public static bool isPlayer;

    void Awake()
    {

        tempAnim = FadeSc.GetComponent<Animation>();
        playerTr = player.GetComponent<Transform>();
        enemyTr = GetComponent<Transform>();
        animator = GetComponent<Animator>();
        moveAgent = GetComponent<MoveAgent>();//추가
        ws = new WaitForSeconds(0.3f);
        animator.SetFloat(hashOffset, Random.Range(1.0f, 1.1f));
        animator.SetFloat(hashWalkSpeed, Random.Range(1.0f, 1.1f));
        enemyFov = GetComponent<EnemyFov>();

    }

void OnEnable()
    {
        StartCoroutine(CheckState());
        StartCoroutine(Action());//추가
    }

    IEnumerator CheckState() {
        yield return new WaitForSeconds(1.0f);

        while (!isClear) {
            if (state == State.Clear) {
                yield break;
            }
            dist = Vector3.Distance(playerTr.position, enemyTr.position);

            if (dist <= attackDist)//플레이어와 거리값이 2 이하일때
            {
                if (enemyFov.isViewPlayer())
                    state = State.ATTACK;
                else
                state = State.TRACE;
            }
            else if (enemyFov.isTracePlayer())//플레이어와 거리값이 10 이하일때
            {
                state = State.TRACE;
            }
            else {
                
               state = State.PATROL; //일반적인 상태
            }
            yield return ws;
        }
    }
    IEnumerator Action()
    {
       
        while (!isClear) {
            yield return ws;

            switch (state) {
                case State.PATROL:
                    moveAgent.patrolling = true;
                    animator.SetBool(hashKillPlayer, false);
                    animator.SetBool(hashMove, true);

                    break;
                case State.TRACE:
                    moveAgent.traceTarget = playerTr.position;
                    animator.SetBool(hashKillPlayer, false);
                    animator.SetBool(hashMove, true);
                    if (!foundS.isPlaying)//
                    {
                        foundS.Play();
                    }


                    break;
                case State.ATTACK:
                    moveAgent.Stop();//필요없
                    animator.SetBool(hashMove, false);
                    animator.SetBool(hashKillPlayer, true);
                    GetComponent<AudioSource>().Stop();
                    ShadowLaugh.Play();
                    player.GetComponent<FirstPersonController>().enabled = false;
                    // player.transform.rotation = Quaternion.LookRotation(this.transform.position);
                    playerFirst.SetActive(false);
                    EnemyCamera.SetActive(true);
                    //yield return new WaitForSeconds(1.0f);
                    tempAnim.Play("FadeScAnim2");//화면 검정 
                    yield return new WaitForSeconds(4.0f);

                    KeyCheck.isNightmare = false;
                    KeyCheck.phoneKey = false;
                    KeyCheck.haveDoll = false;
                    KeyCheck.haveKnife = false;
                    KeyCheck.haveLighter = false;

                    SceneManager.LoadScene(1);
                    StopAllCoroutines();
                    break;
                case State.Clear:
                    moveAgent.Stop();//필요없
                    break;


            }
        }
    }
    void Update()
    {
            animator.SetFloat(hashSpeed, moveAgent.speed);    //Animator 에서 speed 파라미터에 이동속도값을 전송
    
    }
}
