﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class MoveAgent : MonoBehaviour
{
    private readonly float patrolSpeed = 1.5f;
    private readonly float traceSpeed = 5.0f;//Animator 에서 설정 Speed 가 4.0f를 넘어서면 달리는걸로

    public List<Transform> wayPoints;
    public int nextIdx;
    private float damping;

    public GameObject group;
    private NavMeshAgent agent;
    private Transform enemyTr;

    private bool _patrolling;

    public bool patrolling {
        get { return _patrolling; }
        set {
            //foundS.Stop(); 
            _patrolling = value;
            if (_patrolling) {
                agent.speed = patrolSpeed;
                damping = 1.0f;
                MoveWayPoint();//set 으로 patrol 일시에 MoveWayPoint 함수를 실행시키네.
            }
        }
    }

    private Vector3 _traceTarget;

    public Vector3 traceTarget
    {
        get { return _traceTarget; }
        set
        {
            //foundS.Play();
               _traceTarget = value;
                agent.speed = traceSpeed;
            damping = 7.0f;//이값을 크게 하면 빨리 돌아본다
                TraceTarget(_traceTarget);//set 으로 patrol 일시에 MoveWayPoint 함수를 실행시키네.
       }
        
    }

    public float speed {
        get { return agent.velocity.magnitude; }
    }


    // Start is called before the first frame update
    void Start()
    {
        
        agent = GetComponent<NavMeshAgent>();
        agent.autoBraking = false;
        agent.updateRotation = false;
    agent.speed = patrolSpeed;
        enemyTr = GetComponent<Transform>();

        //var group = GameObject.Find("WayPointGroup");
        if (group != null)
        {
            group.GetComponentsInChildren<Transform>(wayPoints);
            wayPoints.RemoveAt(0);
            nextIdx = Random.Range(0, wayPoints.Count);
        }

        //MoveWayPoint();
        this.patrolling = true;
    }

    void MoveWayPoint()
    {
        //Debug.Log(agent.isPathStale);
        if (agent.isPathStale) return;

        agent.destination = wayPoints[nextIdx].position;//이걸 nextidx를 랜덤으로 하면 랜덤으로 이동한다.
        agent.isStopped = false;
    }


void TraceTarget(Vector3 pos) {
        if (agent.isPathStale) return;

        agent.destination = pos;
        agent.isStopped = false;
}

    public void Stop() {//필요없
        agent.isStopped = true;
        agent.velocity = Vector3.zero;
        _patrolling = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (agent.isStopped == false) {
            Quaternion rot = Quaternion.LookRotation(agent.desiredVelocity);
            enemyTr.rotation = Quaternion.Slerp(enemyTr.rotation, rot, Time.deltaTime * damping);
        }

        if (!_patrolling) return;
        if (agent.velocity.sqrMagnitude >= 0.2f * 0.2f && agent.remainingDistance <= 0.5f)
        {
            // nextIdx = ++nextIdx % wayPoints.Count;//이건 배치된 순서대로 이동하면서 순찰이고 
            nextIdx = Random.Range(0, wayPoints.Count);//이건 랜덤으로 이동
            MoveWayPoint();
        }
    }
}
