﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityStandardAssets.Characters.FirstPerson;

public class MainOB1 : MonoBehaviour
{

    public GameObject Player;
    //public GameObject Door;
    // private Animation tempAnim;


    public int stageNum;
    private void Start()
    {
      //  tempAnim = Door.GetComponent<Animation>();

    }
    void OnTriggerEnter()
    { 
            Player.GetComponent<FirstPersonController>().enabled = false;
        KeyCheck.playerPos = Player.GetComponent<Transform>().position;
        KeyCheck.startRoom = stageNum;
            SceneManager.LoadScene(2);
    }

}
