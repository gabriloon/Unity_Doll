﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HoldRot1 : MonoBehaviour
{//RigidBody의 컴포넌트가 있는 들고 싶은 물체에다가 이 Script를 넣는다.

    public Transform theDest;//플레이어하위로 오브젝트 생성후(이름을 Destination) 에 위치를 플레이어 바로 앞으로 놔둔다. 
    private float Distance;
    public GameObject Player;
    public GameObject holdIcon;
    private void OnMouseOver()
    {
        Distance = Vector3.Distance(Player.transform.position, this.transform.position);
        if (Distance < 3.5f)
        {
            holdIcon.SetActive(true);
        }
        else
        {
            holdIcon.SetActive(false);
        }
    }
    void OnMouseExit()
    {
        holdIcon.SetActive(false);
    }

    void OnMouseDown()
    {
        Distance = Vector3.Distance(Player.transform.position, this.transform.position);
        if (Distance < 3.5f)
        {
            GetComponent<BoxCollider>().enabled = false;
            GetComponent<Rigidbody>().useGravity = false;
            GetComponent<Rigidbody>().isKinematic = true;
            GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotationZ | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationX;
            this.transform.position = theDest.position;
            this.transform.parent = GameObject.Find("Destination").transform;
        }
    }
    void OnMouseUp()
    {
        this.transform.parent = null;
        GetComponent<Rigidbody>().useGravity = true;
        GetComponent<BoxCollider>().enabled = true;
        GetComponent<Rigidbody>().isKinematic = false;
        //GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
    }
}

