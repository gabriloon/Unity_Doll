﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class StartPlayerNoSound : MonoBehaviour
{
    public GameObject player;
    public GameObject playerSpe;//플레이어 말하는거
    public GameObject AudioList;//초기에 떨어지는 소리 안들리기 위한 오디오 리스너
 
    public GameObject FadeSc;//
    //public GameObject Day1Ob;
    //public GameObject Day2Ob;
    //public GameObject EatOb;
   // public GameObject NoteBook;
   
    //public GameObject HallPaper;//추후에 작업 또는 미필요
    //public GameObject LightTrigger;

    private Text TempText;
    private AudioListener tempAu;
    private Animation fadeAnim;//

   // public GameObject Clock1;
  //  public GameObject Clock2;


    //keycheck.isNightmare 이용 해서 플레이어 위치랑 nightmare object,휴대폰 SetActive(true)로 설정

    // Start is called before the first frame update
    void Start()
    {
        /*
            KeyCheck.isNightmare = false;
               KeyCheck.phoneKey = false;
               KeyCheck.haveDoll = false;
               KeyCheck.haveKnife = false;
               KeyCheck.haveLighter = false;
         시작할때 처리보다 씬 끝날때 처리하는걸로 변경   
         */

        playerSpe.SetActive(true);
        tempAu = AudioList.GetComponent<AudioListener>();
        TempText = playerSpe.GetComponent<Text>();
        fadeAnim = FadeSc.GetComponent<Animation>();
    
            StartCoroutine(SpeechContent1());
        
    }

    IEnumerator SpeechContent1()
    {

       // Clock1.SetActive(false);
       // Clock2.SetActive(true);


        //FadeScreenIn.SetActive(false);
        tempAu.enabled = false;
        yield return new WaitForSeconds(0.5f);
        tempAu.enabled = true;
        fadeAnim.Play("FadeScAnim3");
        yield return new WaitForSeconds(5.0f);

    }
    /*
    IEnumerator SpeechContent2() {//안써가지고 위에서 코루틴 호출을 안시킴
        Day2Ob.SetActive(true);
        tempAu.enabled = false;
        Day1Ob.SetActive(false);
        EatOb.SetActive(true);
        //HallPaper.SetActive(true);
        LightTrigger.SetActive(true);
        NoteBook.GetComponent<Transform>().position = telePos2.GetComponent<Transform>().position;
        NoteBook.GetComponent<Transform>().eulerAngles = new Vector3(0, -120, 0);

        yield return new WaitForSeconds(0.5f);
        tempAu.enabled = true;
        fadeAnim.Play("FadeScAnim4");
        yield return new WaitForSeconds(5.0f);

    }
    */
}