﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;


public class footstepChange : MonoBehaviour
{
    public GameObject Player;
    public AudioClip step1;
    public AudioClip step2;

    public GameObject footStepOb;

    public int SetIndex;

    public void OnTriggerEnter(Collider other)
    {
        //Player.GetComponent<FirstPersonController>().m_FootstepSounds[0] = step1;
       // Player.GetComponent<FirstPersonController>().m_FootstepSounds[1] = step2;
        this.GetComponent<BoxCollider>().enabled = false;
        footStepOb.GetComponent<BoxCollider>().enabled = true;
        KeyCheck.isInOut = SetIndex;
    }
}
