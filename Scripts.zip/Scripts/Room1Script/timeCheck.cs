﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class timeCheck : MonoBehaviour
{
    public float TimeCost = 10;

    public GameObject textUI;

    private Text tempText;
    // Start is called before the first frame update
    void Start()
    {
        tempText = textUI.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        TimeCost -= Time.deltaTime;
        tempText.text = "" + (int)TimeCost;
    }
}
