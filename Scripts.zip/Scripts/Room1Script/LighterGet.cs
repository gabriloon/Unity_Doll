﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityStandardAssets.Characters.FirstPerson;
public class LighterGet : MonoBehaviour
{
    public GameObject InterIcon;
    public GameObject Aim;
    public GameObject FadeSc;

    public GameObject Player;
    public GameObject enemy;
    public AudioSource enemySound;

    public GameObject dollMesh;
    public GameObject doll;

    public GameObject lighter;
    public GameObject fire;
    public AudioSource lighter1;
    public AudioSource lighter2;

    private float dist;
    private Animation tempAnim;

    private void Start()
    {
        tempAnim = FadeSc.GetComponent<Animation>();
    }


    void OnMouseOver()
    {

        dist = PlayRay.DistanceFromTarget;
        if (dist <= 4.0)
        {

            InterIcon.SetActive(true);
            Aim.SetActive(false);

            if (Input.GetButtonDown("Interaction"))
            {
                StartCoroutine(GetLighter());
            }

        }
    }

    IEnumerator GetLighter()
    {

        if (KeyCheck.haveDoll) {
            enemy.SetActive(false);
            enemySound.Stop();
           // Player.GetComponent<FirstPersonController>().enabled = false;
            this.GetComponent<BoxCollider>().enabled = false;
            lighter.SetActive(false);
            //라이터 키는 음성 재생과 라이터 효과
            //인형 불로 타는 모습 인형에 paticle 효과 추가하는거지
            //인형 보여줘야 되네
            lighter1.Play();
            yield return new WaitForSeconds(1.0f);
            lighter2.Play();
            yield return new WaitForSeconds(1.0f);
            dollMesh.SetActive(true);
            doll.transform.position = Player.transform.position + new Vector3(0f, -0.5f, 0f);
            fire.SetActive(true);
            yield return new WaitForSeconds(6.0f);
            tempAnim.Play("FadeScAnim2");//화면 검정 


            yield return new WaitForSeconds(2.0f);
            fire.SetActive(false);
            KeyCheck.Room1 = 1;
            KeyCheck.isNightmare = false;
            KeyCheck.phoneKey = false;
            KeyCheck.haveDoll = false;
            KeyCheck.haveKnife = false;
            KeyCheck.haveLighter = false;

            SceneManager.LoadScene(1);
        }
        else {
            KeyCheck.haveLighter = true;
            lighter.SetActive(false);
            this.GetComponent<BoxCollider>().enabled = false;
        }

        InterIcon.SetActive(false);
        Aim.SetActive(true);
    }
   

    
    void OnMouseExit()
    {
        InterIcon.SetActive(false);
        Aim.SetActive(true);
    }
}
