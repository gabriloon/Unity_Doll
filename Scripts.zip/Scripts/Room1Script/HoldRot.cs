﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

public class HoldRot : MonoBehaviour
{//RigidBody의 컴포넌트가 있는 들고 싶은 물체에다가 이 Script를 넣는다.

    public Transform theDest;//플레이어하위로 오브젝트 생성후(이름을 Destination) 에 위치를 플레이어 바로 앞으로 놔둔다. 
    private float Distance;
    public GameObject Player;
    public GameObject holdIcon;
    public GameObject Aim;
    private PostProcessProfile postProfile;
    public float changeValue=1.0f;
    public float initValue=10.0f;
    public GameObject postObject;

    private void Start()
    {
        postProfile = postObject.GetComponent<PostProcessVolume>().profile;
    }

    private void OnMouseOver()
    {
        Distance = Vector3.Distance(Player.transform.position, this.transform.position);

        if (Distance < 3.5f) {
            holdIcon.SetActive(true);
            Aim.SetActive(false);
        }
        else {
            holdIcon.SetActive(false);
            Aim.SetActive(true);
        }
    }
    void OnMouseExit()
    {
        holdIcon.SetActive(false);
        Aim.SetActive(true);
    }

    void OnMouseDown()
    {
        Distance = Vector3.Distance(Player.transform.position, this.transform.position);
        if (Distance < 2.5f)
        {
            GetComponent<BoxCollider>().enabled = false;
            GetComponent<Rigidbody>().useGravity = false;
            GetComponent<Rigidbody>().isKinematic = true;
            GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotationZ | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationX;
            this.transform.position = theDest.position;
            this.transform.parent = GameObject.Find("Destination").transform;
            postProfile.GetSetting<DepthOfField>().focusDistance.value = changeValue;
        }
    }
    void OnMouseUp()
    {
        this.transform.parent = null;
        GetComponent<Rigidbody>().useGravity = true;
        GetComponent<BoxCollider>().enabled = true;
        GetComponent<Rigidbody>().isKinematic = false;
        GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
        postProfile.GetSetting<DepthOfField>().focusDistance.value = initValue;
    }
}

