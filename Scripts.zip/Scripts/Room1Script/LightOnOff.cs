﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightOnOff : MonoBehaviour
{
    public GameObject theLightOb;
    //public GameObject thoDoll;
    //public GameObject telePos;
    //public GameObject bedOb;
    public AudioSource tempAudio;
    private Animation tempAnim;
    // Start is called before the first frame update
    void Start()
    {
        tempAnim = theLightOb.GetComponent<Animation>();
    }

   void OnTriggerEnter()
    {
        tempAnim.Play("LightOffOn");
        this.GetComponent<BoxCollider>().enabled = false;
        tempAudio.Play();
        //thoDoll.GetComponent<Transform>().position = telePos.GetComponent<Transform>().position;
        //thoDoll.GetComponent<Transform>().eulerAngles = new Vector3(0,120,0);
        //bedOb.SetActive(true);
        //스탠드 꺼지고 켜지는 소리 재생 깜빡깜빡 소리
    }

}
