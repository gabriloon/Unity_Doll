﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyCheck : MonoBehaviour
{

    //RoomScene;
   public static bool phoneKey;//phoneCollect,FlashLightCtrl 영향,핸드폰 가지고 있는가?
    public static bool haveLighter;
    public static bool haveDoll;
    public static bool haveKnife;
    public static bool isNightmare;
   //
                                 
    public static int startRoom = 0;//이거랑 playerPos는 데이터 저장대신에;
    public static Vector3 playerPos;//?


    public static int Room1;
    public static int Room2;
    public static int Room3;
    public static int isInOut;
    public static int isFirstDoor;
    public static int isSecondDoor;
    //public static bool isClear;
    // Start is called before the first frame update
    // Update is called once per frame
}
