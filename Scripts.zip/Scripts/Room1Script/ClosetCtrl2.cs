﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClosetCtrl2 : MonoBehaviour
{
    public float TheDistance;
    public GameObject ActionDisplay;
    public GameObject HideDoor;
    private bool CloseD = true;
    private Animation tempAnim;
    private AudioSource tempAudio;
    // Start is called before the first frame update
    void Start()
    {
        tempAnim = HideDoor.GetComponent<Animation>();
        tempAudio = HideDoor.GetComponent<AudioSource>();
    }
    void OnMouseOver()
    {//마우스 올라갔을때
        TheDistance = PlayRay.DistanceFromTarget;

        if (TheDistance <= 5.0f && CloseD)
        {
            // ActionDisplay.GetComponent<Text>().text = "Open";
            ActionDisplay.SetActive(true);
            //  ActionText.SetActive(true);
            //Debug.Log("통과2");
        }
        else if ((TheDistance <= 5.0f) && !CloseD)
        {
            // ActionDisplay.GetComponent<Text>().text = "Close";
            ActionDisplay.SetActive(true);
            //  ActionText.SetActive(true);
        }


        if (Input.GetButtonDown("Interaction"))
        {
            //Debug.Log("통과3");
            if (TheDistance <= 5.0f && CloseD)
            {
                //this.GetComponent<BoxCollider>().enable=false;
                //ActionDisplay.GetComponent<Text>().text = "Close";
                ActionDisplay.SetActive(true);
                //  ActionText.SetActive(true);

                tempAnim.Play("ClosetHAnim");

                tempAudio.Play();
                CloseD = false;

            }
            else if ((TheDistance <= 5.0f) && !CloseD)
            {
                //this.GetComponent<BoxCollider>().enabled = false;
                //ActionDisplay.GetComponent<Text>().text = "Open";
                ActionDisplay.SetActive(true);
                // ActionText.SetActive(true);

                tempAnim.Play("ClosetHAnimClose");//닫히는 애니메이션

                tempAudio.Play();
                CloseD = true;

            }
        }
    }


    void OnMouseExit()
    {
        ActionDisplay.SetActive(false);
        // ActionText.SetActive(false);
    }
}