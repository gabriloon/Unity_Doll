﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class BunsinInter : MonoBehaviour
{
    private float Distance;
    //public GameObject player;
    public GameObject holdIcon;
    public GameObject whiteIcon;
    public GameObject Aim;
    public GameObject playerSpe;


    public GameObject ShowOb;//책상위에 랜턴 


    public GameObject StandPlayer;

    public GameObject sitPlayer;



    public bool sit;



    //이걸 겹치는 걸 없애고 간단히 할수 있는데.
    private void OnMouseOver()
    {
        Distance = PlayRay.DistanceFromTarget;


        if (Distance <= 1.5f)
        {
            if (!sit)
            {
                holdIcon.SetActive(true);
                Aim.SetActive(false);
            }
            else {
                whiteIcon.SetActive(true);
                Aim.SetActive(false);

            }
            if (Input.GetButtonDown("Interaction"))
            {
                StartCoroutine(SitDownChair());
            }
        }
        else
        {
            holdIcon.SetActive(false);
            whiteIcon.SetActive(false);
            Aim.SetActive(true);
        }
    }
    void OnMouseExit()
    {
        holdIcon.SetActive(false);
        whiteIcon.SetActive(false);
        Aim.SetActive(true);
    }

    IEnumerator SitDownChair()
    {
        if (sit)
        {
            sitPlayer.SetActive(false);
            StandPlayer.SetActive(true);
            
            ShowOb.SetActive(false);
            
            sit = !sit;
        }
        else
        {
            sitPlayer.SetActive(true);
            StandPlayer.SetActive(false);

            ShowOb.SetActive(true);
            sit = !sit;

        }
        yield return null;

    }
}

